# 🌟 Aventura de Letras y Sílabas — Teacher Dewry

Juego educativo para practicar abecedario, sílabas y formación de palabras.

## 🚀 Publicarlo en GitHub Pages

1. Crea un repositorio nuevo en GitHub.
2. Sube `index.html`, `style.css` y `script.js`.
3. En el repositorio entra a **Settings → Pages**.
4. En **Build and deployment**, selecciona **Deploy from a branch**.
5. Selecciona la rama `main` y la carpeta `/ (root)`.
6. Guarda y espera a que GitHub genere el enlace.

No necesita servidor ni instalación: funciona en el navegador.

## ➕ Para ampliar el juego

Los contenidos están organizados en `script.js`. Puedes añadir palabras en el arreglo `words` y nuevas familias de sílabas en `syllables`.
