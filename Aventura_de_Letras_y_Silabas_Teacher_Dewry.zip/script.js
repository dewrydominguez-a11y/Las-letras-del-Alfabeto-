const letters = [..."ABCDEFGHIJKLMNOPQRSTUVWXYZ"];
const syllables = [
  ["M","MA","ME","MI","MO","MU"],["P","PA","PE","PI","PO","PU"],
  ["L","LA","LE","LI","LO","LU"],["S","SA","SE","SI","SO","SU"],
  ["T","TA","TE","TI","TO","TU"],["N","NA","NE","NI","NO","NU"],
  ["D","DA","DE","DI","DO","DU"],["C","CA","CE","CI","CO","CU"],
  ["B","BA","BE","BI","BO","BU"],["F","FA","FE","FI","FO","FU"]
];
const words = [
  {word:"CASA", parts:["CA","SA"]},{word:"MESA",parts:["ME","SA"]},
  {word:"PATO",parts:["PA","TO"]},{word:"MAMÁ",parts:["MA","MÁ"]},
  {word:"LUNA",parts:["LU","NA"]},{word:"SAPO",parts:["SA","PO"]},
  {word:"TOMATE",parts:["TO","MA","TE"]},{word:"CAMISA",parts:["CA","MI","SA"]},
  {word:"PELOTA",parts:["PE","LO","TA"]},{word:"BANANA",parts:["BA","NA","NA"]}
];

let mode="", items=[], index=0, score=0, lives=3, current=null, locked=false;
const $=id=>document.getElementById(id);
$("year").textContent=new Date().getFullYear();

document.querySelectorAll(".menu-card").forEach(b=>b.onclick=()=>start(b.dataset.mode));
$("backBtn").onclick=home; $("homeBtn").onclick=home;
$("againBtn").onclick=()=>start(mode);
$("nextBtn").onclick=next;
$("soundBtn").onclick=()=>speak(current?.say || current?.display || "");

function start(m){
  mode=m; index=0; score=0; lives=3; $("score").textContent=score; $("lives").textContent=lives;
  items=makeItems(m); shuffle(items); show("game"); next();
}
function makeItems(m){
  if(m==="letters") return letters.slice(0,26).map(l=>({display:l,say:`Letra ${l}`,prompt:`¿Cuál es la letra ${l}?`,answer:l,choices:randomChoices(l,letters)}));
  if(m==="syllables") {
    const arr=[]; syllables.forEach(row=>row.slice(1).forEach(s=>arr.push({display:s,say:`Sílaba ${s}`,prompt:`¿Cuál es la sílaba ${s}?`,answer:s,choices:randomChoices(s,row.slice(1))}))); return arr;
  }
  if(m==="complete") return words.map(w=>{
    const pos=Math.floor(Math.random()*w.parts.length), answer=w.parts[pos];
    const distract=words.flatMap(x=>x.parts).filter(x=>x!==answer);
    return {display:w.parts.map((x,i)=>i===pos?"__":x).join(" - "),say:w.word,prompt:`Completa la palabra ${w.word}.`,answer,choices:randomChoices(answer,[...new Set([...distract])])};
  });
  return words.map(w=>({display:w.parts.map(()=> "□").join(" + "),say:w.word,prompt:`¿Qué palabra se forma con ${w.parts.join(" + ")}?`,answer:w.word,choices:randomChoices(w.word,words.map(x=>x.word))}));
}
function randomChoices(correct,pool){
  let a=[correct,...pool.filter(x=>x!==correct)]; shuffle(a); return [...new Set(a)].slice(0,4);
}
function next(){
  if(index>=items.length){finish();return}
  locked=false; $("nextBtn").classList.add("hidden"); $("feedback").textContent="";
  current=items[index]; $("progressBar").style.width=(index/items.length*100)+"%";
  $("question").innerHTML=`<div class="question-card"><div class="big">${current.display}</div><p>${current.prompt}</p></div>`;
  $("answers").innerHTML="";
  current.choices.forEach(c=>{
    const b=document.createElement("button"); b.className="answer"; b.textContent=c;
    b.onclick=()=>answer(c,b); $("answers").appendChild(b);
  });
}
function answer(choice,btn){
  if(locked)return; locked=true;
  const ok=choice===current.answer;
  document.querySelectorAll(".answer").forEach(b=>{if(b.textContent===current.answer)b.classList.add("correct");});
  if(ok){score+=10;$("feedback").textContent="🎉 ¡Muy bien! +10 puntos";btn.classList.add("correct");}
  else{lives--; $("lives").textContent=lives;btn.classList.add("wrong");$("feedback").textContent=`💡 La respuesta correcta es ${current.answer}`;}
  $("score").textContent=score;$("nextBtn").classList.remove("hidden");
  if(lives<=0){setTimeout(finish,700)}
}
function finish(){
  $("progressBar").style.width="100%"; show("result");
  const max=items.length*10, pct=max?score/max:0;
  const medal=pct>=.9?"🥇 ¡Medalla de oro!":pct>=.7?"🥈 ¡Medalla de plata!":"🥉 ¡Sigue practicando!";
  $("resultText").textContent=`Obtuviste ${score} de ${max} puntos.`;
  $("medal").textContent=medal;
}
function home(){show("home")}
function show(id){document.querySelectorAll(".screen").forEach(s=>s.classList.remove("active"));$(id).classList.add("active")}
function shuffle(a){for(let i=a.length-1;i>0;i--){let j=Math.floor(Math.random()*(i+1));[a[i],a[j]]=[a[j],a[i]]}}
function speak(t){if("speechSynthesis" in window && t){speechSynthesis.cancel();let u=new SpeechSynthesisUtterance(t);u.lang="es-ES";u.rate=.8;speechSynthesis.speak(u)}}
